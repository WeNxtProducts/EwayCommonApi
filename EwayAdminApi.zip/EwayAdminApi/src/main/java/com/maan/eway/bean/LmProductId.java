package com.maan.eway.bean;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LmProductId implements Serializable {
	
	
	   private static final long serialVersionUID = 1L;

	    private String     prodCode ;
	    
	    private String     prodPlanCode ;
	    
	    private Integer    amendId ;
	        
	    private String companyid;


}
