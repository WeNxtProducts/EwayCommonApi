package com.maan.eway.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@IdClass(LmPlanId.class)
@Table(name="lm_plan")
public class LmPlan implements Serializable {

	private static final long serialVersionUID = 1L;
	 
	 
    //--- ENTITY PRIMARY KEY 
    @Id
    @Column(name="PLAN_CODE", nullable=false, length=12)
    private String     planCode ;

   
    
    @Id
    @Column(name="PLAN_PROD_CODE", nullable=false, length=12)
    private String     planProdCode ;

    @Id
    @Column(name="AMEND_ID", nullable=false)
    private Integer    amendId ;
    
    @Column(name="PLAN_NAME")
    private String planName;
    
    @Id
    @Column(name="PLAN_TYPE")
    private String planType;
    
    @Column(name="PLAN_PERIOD_FM")
    private Integer    planPeriodFm ;

    @Column(name="PLAN_PERIOD_TO")
    private Integer    planPeriodTo ;
    
    @Column(name="PLAN_AGE_FROM")
    private Integer planAgeFrom;
    
    @Column(name="PLAN_AGE_TO")
    private Integer planAgeTo;
    
    @Column(name="PLAN_LOAN_YN")
    private String planLoanYn;
    
    @Column(name="PLAN_FACIN_YN")
    private String planFacinYn;
    
    @Column(name="PLAN_PYTM_ON_MAT_YN")
    private String planPytmOnMatYn;
    
    @Column(name="PLAN_SA_INST_YN")
    private String planSaInstYn;
    
    @Column(name="PLAN_REBATE_YN")
    private String planRebateYn;
    
    @Column(name="PLAN_SURR_YN")
    private String planSurrYN;
    
    @Column(name="PLAN_SURR_YRS")
    private Integer planSurrYrs;
    
    @Column(name="PLAN_RED_SA_BASIS")
    private String planRedSaBasis;
    
    @Column(name="PLAN_FRZ_FLAG")
    private String planFrzFlag;
    
    @Column(name="PLAN_PROP_AGE_FM")
    private Integer planPropAgeFm;
    
    @Column(name="PLAN_PROP_AGE_TO")
    private Integer planPropAgeTo;
    
    @Column(name="EFFECTIVE_DATE_START")
    private Date       effectiveDateStart ;


    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="EFFECTIVE_DATE_END")
    private Date       effectiveDateEnd ;
    
    @Column(name="STATUS", length=1)
    private String     status ;

    @Column(name="PLAN_STATUS")
    private String planStatus;
    
    @Column(name="PLAN_MAT_MAX_AGE")
    private Integer planMatMAxAge;
    
    @Column(name="PLAN_MIN_SA")
    private Double     planMinSa ;

    @Column(name="PLAN_MAX_SA")
    private Double     planMaxSa ;
  
    @Column(name="PLAN_MULTIPLE_YN")
    private String planMultipleYn;

    @Column(name="PLAN_MULTIPLE")
    private Integer planMultiple;
    
    
    @Column(name="PLAN_SA_FACTOR", length=12)
    private String     planSaFactor ;
    
    
    @Column(name="ENTRY_DATE")
    private Date       entryDate ;
    
    @Column(name="CREATED_BY")
    private String createdBy;
    
    @Column(name="UPDATED_BY")
    private String updatedBy;
    
    @Column(name="UPDATED_DATE")
    private Date updatedDate;

    
 
}