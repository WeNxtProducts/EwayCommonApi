package com.maan.eway.master.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maan.eway.bean.LmProduct;
import com.maan.eway.common.res.CommonRes;
import com.maan.eway.excelconfig2.DropDownRes;
import com.maan.eway.master.req.CityChangeStatusReq;
import com.maan.eway.master.req.LmProductChangeStatus;
import com.maan.eway.master.req.LmProductDrpDownReq;
import com.maan.eway.master.req.LmProductGetDetailsReq;
import com.maan.eway.master.req.LmProductSaveRequest;
import com.maan.eway.master.res.LmProductRes;
import com.maan.eway.master.res.LmProductResponse;
import com.maan.eway.master.service.LmProductService;
import com.maan.eway.repository.LmProductRepository;
import com.maan.eway.res.DropdownCommonRes;
import com.maan.eway.res.SuccessRes;

@RestController
@RequestMapping(value="/lmproductapi")
public class LmProductController {
	
	@Autowired
	private LmProductService lmproductservice;
	
	@Autowired
	private LmProductRepository lmproductrepo;
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@GetMapping(value="/getproductdetails")
	public List<LmProduct> getproduct()
	{
		List<LmProduct> product = lmproductrepo.findAll();
		return product;
	}
	
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping(value= "/insertproduct")
	public ResponseEntity<CommonRes> insertproduct(@RequestBody LmProductSaveRequest req)
	{
		CommonRes valids = new CommonRes();
		
		List<com.maan.eway.error.Error> validation = lmproductservice.validation(req);
		
		if(validation != null && validation.size() != 0)
		{
			valids.setIsError(true);
			valids.setErrorMessage(validation);
			valids.setCommonResponse(null);
			valids.setMessage("failed");
			return new ResponseEntity<CommonRes>(valids, HttpStatus.OK);
		}
		else
		{
			SuccessRes res = lmproductservice.saveproducts(req);
			valids.setCommonResponse(res);
			valids.setIsError(false);
			valids.setErrorMessage(Collections.emptyList());
			valids.setMessage("Success");

			if(res != null)
			{	
			   return new ResponseEntity<CommonRes>(valids, HttpStatus.CREATED);
			}
			else
			{
				return new ResponseEntity<>(null, HttpStatus.CREATED);
			}
		}
	}
	
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping(value = "/getallproductdetails")
	public ResponseEntity<CommonRes> getallproductdetails(@RequestBody LmProductGetDetailsReq req)
	{
		CommonRes data = new CommonRes();
		List<LmProductResponse> res = lmproductservice.getallproductdetails(req);
		data.setCommonResponse(res);
		data.setErrorMessage(null);
		data.setIsError(false);
		data.setMessage("Success");
		
		if(res != null)
		{
			return new ResponseEntity<CommonRes>(data,HttpStatus.CREATED);
		}
		else
		{
	    	return new ResponseEntity<CommonRes>(data, HttpStatus.BAD_REQUEST); 
		}
	}
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping("/getactiveproduct")
	public ResponseEntity<CommonRes> getactivecity(@RequestBody LmProductGetDetailsReq req)
	{
		CommonRes data = new CommonRes();
		List<LmProductResponse> res = lmproductservice.getproductCityDetails(req);
		
		data.setCommonResponse(res);
		data.setErrorMessage(null);
		data.setIsError(false);
		data.setMessage("Success");
		
		if(res != null)
		{
			return new ResponseEntity<CommonRes>(data,HttpStatus.CREATED);
		}
		else
		{
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
	}
	
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping("/getproductbyid")
	public ResponseEntity<CommonRes> getcitybyid(@RequestBody LmProductGetDetailsReq req)
	{
		CommonRes data = new CommonRes();
		List<LmProductResponse> res = lmproductservice.getproductById(req);
		
		data.setCommonResponse(res);
		data.setErrorMessage(null);
		data.setIsError(false);
		data.setMessage("Success");
		
		if(res != null)
		{
			return new ResponseEntity<CommonRes>(data,HttpStatus.CREATED);
		}
		else
		{
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
	}
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping("/changestatus")
	public ResponseEntity<CommonRes> changestatusofproduct(@RequestBody LmProductChangeStatus req)
	{
		CommonRes res = new CommonRes();
		
		SuccessRes success = lmproductservice.changeStatusofproduct(req);
		res.setCommonResponse(success);
		res.setIsError(false);
		res.setErrorMessage(null);
		res.setMessage("Success");
		
		if(success != null)
		{
			return new ResponseEntity<CommonRes>(res,HttpStatus.CREATED);
		}
		else
		{
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping("/dropdownproduct")
	public ResponseEntity<DropdownCommonRes> getLmProductDropDown(@RequestBody LmProductDrpDownReq req)
	{
		DropdownCommonRes data = new DropdownCommonRes();
		
		List<com.maan.eway.res.DropDownRes> res = lmproductservice.getproductDropDown(req);
		
		data.setCommonResponse(res);
		data.setIsError(false);
		data.setErrorMessage(null);
		data.setMessage("Success");
		
		if(res != null)
		{
			return new ResponseEntity<DropdownCommonRes>(data,HttpStatus.CREATED);
		}
		else
		{
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
		
	}
	
	

}
