package com.maan.eway.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@IdClass(LmProductId.class)
@Table(name="lm_product")
public class LmProduct implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	 
	 
    //--- ENTITY PRIMARY KEY 
    @Id
    @Column(name="PROD_CODE", nullable=false, length=12)
    private String     prodCode ;

    @Id
    @Column(name="COMPANY_ID")
    private String companyid;
    
    @Id
    @Column(name="PROD_PLAN_CODE", nullable=false, length=12)
    private String     prodPlanCode ;

    @Id
    @Column(name="AMEND_ID", nullable=false)
    private Integer    amendId ;

    //--- ENTITY DATA FIELDS 
    @Column(name="PROD_DESC", length=60)
    private String     prodDesc ;

    @Column(name="PROD_SHORT_DESC", length=30)
    private String     prodShortDesc ;

    @Column(name="PROD_LONG_DESC", length=240)
    private String     prodLongDesc ;

    @Column(name="PROD_BL_DESC", length=100)
    private String     prodBlDesc ;

    @Column(name="PROD_BL_SHORT_DESC", length=100)
    private String     prodBlShortDesc ;

    @Column(name="PLAN_CODE_DESC", length=100)
    private String     planCodeDesc ;

    @Column(name="PROD_BL_LONG_DESC", length=200)
    private String     prodBlLongDesc ;

    @Column(name="PROD_MIN_SA")
    private Double     prodMinSa ;

    @Column(name="PROD_MAX_SA")
    private Double     prodMaxSa ;

    @Column(name="MIN_ENTRY_AGE")
    private Integer    minEntryAge ;

    @Column(name="PROD_PERIOD_FM")
    private Integer    prodPeriodFm ;

    @Column(name="MAX_ENTRY_AGE")
    private Integer    maxEntryAge ;

    @Column(name="PROD_PERIOD_TO")
    private Integer    prodPeriodTo ;

    @Column(name="MIN_PAYING_TERM")
    private Integer    minPayingTerm ;

    @Column(name="MAX_PAYING_TERM")
    private Integer    maxPayingTerm ;

    @Column(name="MIN_TERM_ALLOWED")
    private Integer    minTermAllowed ;

    @Column(name="MAX_TERM_ALLOWED")
    private Integer    maxTermAllowed ;

    @Column(name="PROD_TOPUP_YN", length=1)
    private String     prodTopupYn ;

    @Column(name="PROD_TOPUP_MIN_YRS")
    private Double     prodTopupMinYrs ;

    @Column(name="PROD_MIN_MEM_COUNT")
    private Double     prodMinMemCount ;

    @Column(name="EFFECTIVE_DATE_START")
    private Date       effectiveDateStart ;

    @Column(name="COVER_BENEFITS")
    private Integer    coverBenefits ;

    @Column(name="IS_BONUS", length=5)
    private String     isBonus ;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="EFFECTIVE_DATE_END")
    private Date       effectiveDateEnd ;

    @Column(name="BONUS_RATE")
    private Double     bonusRate ;

    @Column(name="PROD_CASHBACK_YN", length=1)
    private String     prodCashbackYn ;

    @Column(name="CASH_BACK_YEAR")
    private Integer    cashBackYear ;

    @Column(name="IS_SURRENDER", length=5)
    private String     isSurrender ;

    @Column(name="IS_LOAN", length=5)
    private String     isLoan ;

    @Column(name="LOAN_ELIGIBLE_YEAR")
    private Integer    loanEligibleYear ;

    @Column(name="LAPSATION_PERIOD")
    private Integer    lapsationPeriod ;

    @Column(name="ENTRY_DATE")
    private Date       entryDate ;

    @Column(name="STATUS", length=1)
    private String     status ;

    @Column(name="PROD_PREM_PAY_YRS")
    private Double     prodPremPayYrs ;

    @Column(name="PROD_AGE_CALC_FLAG", length=1)
    private String     prodAgeCalcFlag ;

    @Column(name="PROD_JOINT_LIFE_YN", length=1)
    private String     prodJointLifeYn ;

    @Column(name="PROD_TARIFF_TERM_FLAG", length=1)
    private String     prodTariffTermFlag ;

    @Column(name="PROD_SA_INST_PYMT_TYPE", length=1)
    private String     prodSaInstPymtType ;


    @Column(name="PROD_CR_DATE")
    private Date       prodCrDate ;

    @Column(name="PROD_CR_USER", length=12)
    private String     prodCrUser ;

    @Column(name="PROD_UPD_DATE")
    private Date       prodUpdDate ;

    @Column(name="PROD_UPD_USER", length=12)
    private String     prodUpdUser ;

    @Column(name="PROD_ENDT_VAL_DAYS")
    private Double     prodEndtValDays ;

    @Column(name="PROD_MAX_DEFER_MONTHS")
    private Double     prodMaxDeferMonths ;

    @Column(name="PROD_COOLOFF_DAYS")
    private Double     prodCooloffDays ;

    @Column(name="PROD_MORT_CODE", length=12)
    private String     prodMortCode ;

    @Column(name="PROD_CBC_YN", length=1)
    private String     prodCbcYn ;

    @Column(name="PROD_AGE_SET_BACK")
    private Double     prodAgeSetBack ;

    @Column(name="PROD_WITHDRAW_YN", length=1)
    private String     prodWithdrawYn ;

    @Column(name="PROD_COMM_CODE", length=12)
    private String     prodCommCode ;

    @Column(name="PROD_COMM_RND_DEC")
    private Double     prodCommRndDec ;

    @Column(name="PROD_COMM_RND_TYPE", length=1)
    private String     prodCommRndType ;

    @Column(name="PROD_COMM_CALC_MTHD", length=1)
    private String     prodCommCalcMthd ;

    @Column(name="PROD_PRODUCTION_PERC")
    private Double     prodProductionPerc ;

    @Column(name="PROD_THRESHOLD_PERC")
    private Double     prodThresholdPerc ;

    @Column(name="PROD_DOC_CODE", length=12)
    private String     prodDocCode ;

    @Column(name="PROD_TOPUP_PROD_PERC")
    private Double     prodTopupProdPerc ;

    @Column(name="PROD_PREM_CALC_MTHD", length=1)
    private String     prodPremCalcMthd ;

    @Column(name="PROD_INST_BASIS", length=1)
    private String     prodInstBasis ;

    @Column(name="PROD_INST_PERC")
    private Double     prodInstPerc ;

    @Column(name="PROD_AUTO_APPROV", length=1)
    private String     prodAutoApprov ;

    @Column(name="PROD_INST_RATE_PER")
    private Double     prodInstRatePer ;

    @Column(name="PROD_TOPUP_COMM_CODE", length=12)
    private String     prodTopupCommCode ;

    @Column(name="PROD_ALLOC_TYPE", length=1)
    private String     prodAllocType ;

    @Column(name="PROD_BUY_BASIS", length=1)
    private String     prodBuyBasis ;

    @Column(name="PROD_AUTO_UW", length=1)
    private String     prodAutoUw ;

    @Column(name="PROD_PREM_TARIFF", length=12)
    private String     prodPremTariff ;

    @Column(name="PROD_SA_TARIFF", length=12)
    private String     prodSaTariff ;

    @Column(name="PROD_CALC_ALLOC", length=1)
    private String     prodCalcAlloc ;

    @Column(name="PROD_SA_FACTOR", length=12)
    private String     prodSaFactor ;

    @Column(name="PROD_ROUND_OPTION", length=1)
    private String     prodRoundOption ;

    @Column(name="PROD_ROUND_VALUE")
    private Double     prodRoundValue ;

    @Column(name="PROD_MAT_AMT_TYPE", length=5)
    private String     prodMatAmtType ;

    @Column(name="PROD_MAT_RATE")
    private Double     prodMatRate ;

    @Column(name="PROD_MAT_RATE_PER")
    private Double     prodMatRatePer ;

    @Column(name="PROD_MRTA_RATE_CALC_YN", length=1)
    private String     prodMrtaRateCalcYn ;

    @Column(name="PROD_TOPUP_CHARGE_TYPE", length=12)
    private String     prodTopupChargeType ;

    @Column(name="PROD_PREM_HOLIDAY_CODE", length=12)
    private String     prodPremHolidayCode ;

    @Column(name="PROD_LOAD_CHARGE_YN", length=1)
    private String     prodLoadChargeYn ;

    @Column(name="PROD_PRODUCT_TYPE", length=1)
    private String     prodProductType ;

    @Column(name="PROD_GRP_THRESHOLD_PERC")
    private Double     prodGrpThresholdPerc ;

    @Column(name="PROD_MODE_OF_CALC", length=1)
    private String     prodModeOfCalc ;

    @Column(name="PROD_SURR_CALC_TYPE", length=3)
    private String     prodSurrCalcType ;

    @Column(name="PROD_PRS_YN", length=1)
    private String     prodPrsYn ;

    @Column(name="PROD_SURR_PLUS_FACTOR", length=12)
    private String     prodSurrPlusFactor ;

    @Column(name="PROD_AGENT_HIRE_YN", length=1)
    private String     prodAgentHireYn ;

    @Column(name="PROD_MATURITY_DT", length=1)
    private String     prodMaturityDt ;

    @Column(name="PROD_DEF_PERIOD_FLAG", length=1)
    private String     prodDefPeriodFlag ;

    @Column(name="PROD_RSA_CALC_TYP", length=1)
    private String     prodRsaCalcTyp ;

    @Column(name="PROD_SURRENDER_FACTOR", length=12)
    private String     prodSurrenderFactor ;

    @Column(name="PROD_TOLL_LIMIT_YN", length=1)
    private String     prodTollLimitYn ;

    @Column(name="PROD_INTER_FUND_YN", length=1)
    private String     prodInterFundYn ;

    @Column(name="PROD_WITHDRAW_AMT_MULTIPLE")
    private Double     prodWithdrawAmtMultiple ;

    @Column(name="PROD_RI_RECOV_BASIS", length=1)
    private String     prodRiRecovBasis ;

    @Column(name="PROD_SERVICE_TAX_YN", length=1)
    private String     prodServiceTaxYn ;

    @Column(name="PROD_DRIP_MTHD", length=1)
    private String     prodDripMthd ;

    @Column(name="PROD_SA_BY_PLAN_BASIS_YN", length=1)
    private String     prodSaByPlanBasisYn ;

    @Column(name="PROD_MASTER_CERT_YN", length=1)
    private String     prodMasterCertYn ;

    @Column(name="PROD_FUND_ALLOWED", length=1)
    private String     prodFundAllowed ;

    @Column(name="PROD_WAKFEE_FACTOR", length=12)
    private String     prodWakfeeFactor ;

    @Column(name="PROD_DEF_PERIOD_FM")
    private Double     prodDefPeriodFm ;

    @Column(name="PROD_DEF_PERIOD_TO")
    private Double     prodDefPeriodTo ;

    @Column(name="PROD_WAQAF_PERIOD_FM")
    private Double     prodWaqafPeriodFm ;

    @Column(name="PROD_WAQAF_PERIOD_TO")
    private Double     prodWaqafPeriodTo ;

    @Column(name="PROD_AFTWD_LC_MINBAL")
    private Double     prodAftwdLcMinbal ;

    @Column(name="PROD_TOPUP_MULTIPLE")
    private Double     prodTopupMultiple ;

    @Column(name="PROD_TOPUP_WAK_CODE", length=12)
    private String     prodTopupWakCode ;

    @Column(name="PROD_MIN_SURR_AMT")
    private Double     prodMinSurrAmt ;

    @Column(name="PROD_SA_ADD_FACTOR", length=12)
    private String     prodSaAddFactor ;

    @Column(name="PROD_DRIP_LIMIT", length=1)
    private String     prodDripLimit ;

    @Column(name="PROD_TOL_CHK_YN", length=1)
    private String     prodTolChkYn ;

    @Column(name="PROD_TRAN_RATE_YN", length=2)
    private String     prodTranRateYn ;

    @Column(name="PROD_SAL_MULTIPLE")
    private Double     prodSalMultiple ;

    @Column(name="PROD_INC_WEIGHT")
    private Double     prodIncWeight ;

    @Column(name="PROD_RECALC_BASIS", length=10)
    private String     prodRecalcBasis ;

    @Column(name="PROD_RECALC_FREQ", length=1)
    private String     prodRecalcFreq ;

    @Column(name="PROD_FORMULA_SURR", length=200)
    private String     prodFormulaSurr ;

    @Column(name="PROD_PAIDUP_FORMULA", length=200)
    private String     prodPaidupFormula ;

    @Column(name="PROD_IBNR_REQ_YN", length=2)
    private String     prodIbnrReqYn ;

    @Column(name="PROD_APL_YN", length=1)
    private String     prodAplYn ;

    @Column(name="PROD_RISK_FACTOR_YN", length=1)
    private String     prodRiskFactorYn ;

    @Column(name="PROD_UNIT_LINK_TYPE", length=40)
    private String     prodUnitLinkType ;

    @Column(name="PROD_VALID_YN", length=1)
    private String     prodValidYn ;

    @Column(name="PROD_INS_UID", length=15)
    private String     prodInsUid ;

    @Column(name="PROD_FLEX_01", length=15)
    private String     prodFlex01 ;

    @Column(name="PROD_FLEX_02", length=15)
    private String     prodFlex02 ;

    @Column(name="PROD_FLEX_03", length=15)
    private String     prodFlex03 ;

    @Column(name="PROD_FLEX_04", length=15)
    private String     prodFlex04 ;

    @Column(name="PROD_FLEX_05", length=15)
    private String     prodFlex05 ;




}
