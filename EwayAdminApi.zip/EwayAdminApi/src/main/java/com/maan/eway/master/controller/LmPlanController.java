package com.maan.eway.master.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maan.eway.common.res.CommonRes;
import com.maan.eway.master.req.LmPlanChangeReq;
import com.maan.eway.master.req.LmPlanDropDownReq;
import com.maan.eway.master.req.LmPlanGetDetailReq;
import com.maan.eway.master.req.LmPlanRespons;
import com.maan.eway.master.req.LmPlanSaveReq;
import com.maan.eway.master.req.LmProductChangeStatus;
import com.maan.eway.master.req.LmProductDrpDownReq;
import com.maan.eway.master.req.LmProductGetDetailsReq;
import com.maan.eway.master.req.LmProductSaveRequest;
import com.maan.eway.master.res.LmProductResponse;
import com.maan.eway.master.service.LmPlanService;
import com.maan.eway.repository.LmPlanRepository;
import com.maan.eway.res.DropdownCommonRes;
import com.maan.eway.res.SuccessRes;

@RestController
@RequestMapping(value="/lmplanapi")
public class LmPlanController {
	
	@Autowired
	private LmPlanService lmplanservice;

	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping(value= "/insertplan")
	public ResponseEntity<CommonRes> insertproduct(@RequestBody LmPlanSaveReq req)
	{
		CommonRes valids = new CommonRes();
		
		List<com.maan.eway.error.Error> validation = lmplanservice.validation(req);
		
		if(validation != null && validation.size() != 0)
		{
			valids.setIsError(true);
			valids.setErrorMessage(validation);
			valids.setCommonResponse(null);
			valids.setMessage("failed");
			return new ResponseEntity<CommonRes>(valids, HttpStatus.OK);
		}
		else
		{
			SuccessRes res = lmplanservice.saveplans(req);
			valids.setCommonResponse(res);
			valids.setIsError(false);
			valids.setErrorMessage(Collections.emptyList());
			valids.setMessage("Success");

			if(res != null)
			{	
			   return new ResponseEntity<CommonRes>(valids, HttpStatus.CREATED);
			}
			else
			{
				return new ResponseEntity<>(null, HttpStatus.CREATED);
			}
		}
	}

	
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping(value = "/getallplandetails")
	public ResponseEntity<CommonRes> getallproductdetails(@RequestBody LmPlanGetDetailReq req)
	{
		CommonRes data = new CommonRes();
		List<LmPlanRespons> res = lmplanservice.getallplandetails(req);
		data.setCommonResponse(res);
		data.setErrorMessage(null);
		data.setIsError(false);
		data.setMessage("Success");
		
		if(res != null)
		{
			return new ResponseEntity<CommonRes>(data,HttpStatus.CREATED);
		}
		else
		{
	    	return new ResponseEntity<CommonRes>(data, HttpStatus.BAD_REQUEST); 
		}
	}
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping("/getactiveplan")
	public ResponseEntity<CommonRes> getactivecity(@RequestBody LmPlanGetDetailReq req)
	{
		CommonRes data = new CommonRes();
		List<LmPlanRespons> res = lmplanservice.getActiveplanDetails(req);
		
		data.setCommonResponse(res);
		data.setErrorMessage(null);
		data.setIsError(false);
		data.setMessage("Success");
		
		if(res != null)
		{
			return new ResponseEntity<CommonRes>(data,HttpStatus.CREATED);
		}
		else
		{
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
	}
	
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping("/getplanbyid")
	public ResponseEntity<CommonRes> getcitybyid(@RequestBody LmPlanGetDetailReq req)
	{
		CommonRes data = new CommonRes();
		List<LmPlanRespons> res = lmplanservice.getplanById(req);
		
		data.setCommonResponse(res);
		data.setErrorMessage(null);
		data.setIsError(false);
		data.setMessage("Success");
		
		if(res != null)
		{
			return new ResponseEntity<CommonRes>(data,HttpStatus.CREATED);
		}
		else
		{
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
	}
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping("/changestatus")
	public ResponseEntity<CommonRes> changestatusofproduct(@RequestBody LmPlanChangeReq req)
	{
		CommonRes res = new CommonRes();
		
		SuccessRes success = lmplanservice.changeStatusofplan(req);
		res.setCommonResponse(success);
		res.setIsError(false);
		res.setErrorMessage(null);
		res.setMessage("Success");
		
		if(success != null)
		{
			return new ResponseEntity<CommonRes>(res,HttpStatus.CREATED);
		}
		else
		{
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@PreAuthorize("hasAnyRole('ROLE_APPROVER','ROLE_USER','ROLE_ADMIN')")
	@PostMapping("/dropdownplan")
	public ResponseEntity<DropdownCommonRes> getLmProductDropDown(@RequestBody LmPlanDropDownReq req)
	{
		DropdownCommonRes data = new DropdownCommonRes();
		
		List<com.maan.eway.res.DropDownRes> res = lmplanservice.getplanDropDown(req);
		
		data.setCommonResponse(res);
		data.setIsError(false);
		data.setErrorMessage(null);
		data.setMessage("Success");
		
		if(res != null)
		{
			return new ResponseEntity<DropdownCommonRes>(data,HttpStatus.CREATED);
		}
		else
		{
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
		
	}

	
}
